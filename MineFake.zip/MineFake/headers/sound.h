#include <raylib.h>

#define NUM_SONS 20

#ifndef SOUND_H
#define SOUND_H

void loadSounds(Sound som[NUM_SONS]);

#endif // SOUND_H

